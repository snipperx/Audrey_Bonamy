<?php
// Silent Ninja is silent.